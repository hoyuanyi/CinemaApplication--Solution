from src import CinemaClass

def main():
    CINEMA = CinemaClass.CinemaClass()
    CINEMA.movie_menu()
if __name__ == "__main__":
    main()